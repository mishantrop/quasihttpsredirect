<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b4bf4db19a722c9775a40b64b15668fe',
      'native_key' => 'quasihttpsredirect',
      'filename' => 'modNamespace/e570eb5a3590c9a1d78ad8245835b94e.vehicle',
      'namespace' => 'quasihttpsredirect',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'ff026ee5905618cca04559e74b521f77',
      'native_key' => 29,
      'filename' => 'modPlugin/621225165577e8273db3108008777aaa.vehicle',
      'namespace' => 'quasihttpsredirect',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'fb0c93c6eb943371cc628648710152e7',
      'native_key' => 1,
      'filename' => 'modCategory/9c9f1b06685a036350ddd4a3fd4074f0.vehicle',
      'namespace' => 'quasihttpsredirect',
    ),
  ),
);