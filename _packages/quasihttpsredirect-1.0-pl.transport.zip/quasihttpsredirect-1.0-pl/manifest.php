<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd7206ac7c691ab316471c0714aeba629',
      'native_key' => 'quasihttpsredirect',
      'filename' => 'modNamespace/d5fe8026d55d8ab3837692848e72bb41.vehicle',
      'namespace' => 'quasihttpsredirect',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '82d25438ca58fb49c877a44932e701fc',
      'native_key' => 29,
      'filename' => 'modPlugin/8a49a93c8b15fd04ef6c2784f7a6b921.vehicle',
      'namespace' => 'quasihttpsredirect',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '176610a248f59101a5d38d726f2c1469',
      'native_key' => 1,
      'filename' => 'modCategory/e443bc2d843535e9508b7e796534e276.vehicle',
      'namespace' => 'quasihttpsredirect',
    ),
  ),
);